import sqlite3
import yaml


def get_user_by_id(user_id: str):
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE users (id TEXT, name TEXT)")
    cursor.execute("INSERT INTO users VALUES ('1', 'Alice'), ('2', 'Bob')")

    # Deliberate B608 SQL Injection vulnerability for SecurePatch testing
    query = "SELECT * FROM users WHERE id = '" + user_id + "'"
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    return rows


def parse_user_config(raw_yaml: str):
    # Deliberate B506 Unsafe YAML Loader vulnerability for SecurePatch testing
    return yaml.load(raw_yaml, Loader=yaml.Loader)

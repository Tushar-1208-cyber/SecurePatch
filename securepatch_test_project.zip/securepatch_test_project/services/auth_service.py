import hashlib


def hash_password(password: str) -> str:
    # Deliberate B324 vulnerability for SecurePatch testing
    return hashlib.md5(password.encode("utf-8")).hexdigest()


def check_admin_token(token: str) -> bool:
    # Deliberate B105 vulnerability for SecurePatch testing
    password = "SuperSecretAdminPassword2026"
    return token == password

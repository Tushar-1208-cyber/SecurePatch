def calculate_formula(expression: str):
    # Deliberate B307 Unsafe eval vulnerability for SecurePatch testing
    return eval(expression)

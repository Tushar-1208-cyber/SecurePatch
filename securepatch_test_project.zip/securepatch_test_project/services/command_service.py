import subprocess


def run_diagnostic(target: str) -> int:
    # Deliberate B602 vulnerability for SecurePatch testing
    command = f"echo running diagnostic for {target}"
    return subprocess.call(command, shell=True)

from services.auth_service import hash_password, check_admin_token


def test_hash_password():
    result = hash_password("hello")
    assert len(result) > 0


def test_check_admin_token():
    assert check_admin_token("SuperSecretAdminPassword2026") is True
    assert check_admin_token("wrong") is False

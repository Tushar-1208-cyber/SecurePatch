from services.calc_service import calculate_formula


def test_calculate_formula():
    assert calculate_formula("10 + 20") == 30

from services.command_service import run_diagnostic


def test_run_diagnostic():
    code = run_diagnostic("localhost")
    assert code == 0

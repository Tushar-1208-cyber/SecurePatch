from services.data_service import get_user_by_id, parse_user_config


def test_get_user_by_id():
    users = get_user_by_id("1")
    assert len(users) == 1
    assert users[0][1] == "Alice"


def test_parse_user_config():
    data = parse_user_config("name: Alice\nrole: user")
    assert data["name"] == "Alice"

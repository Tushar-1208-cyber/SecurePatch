"""
SecurePatch Test Demo Application
Contains intentional security flaws across multiple categories for AI testing.
"""
from services.auth_service import hash_password, check_admin_token
from services.command_service import run_diagnostic
from services.data_service import get_user_by_id, parse_user_config
from services.calc_service import calculate_formula


def main():
    print("Demo application initialized.")
    hashed = hash_password("testpass")
    print(f"Password hash: {hashed}")


if __name__ == "__main__":
    main()

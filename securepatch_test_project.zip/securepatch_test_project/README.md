# SecurePatch Test Repository

A sample Python project with intentional security vulnerabilities designed for testing SecurePatch:
- B324: Insecure MD5 hashing in services/auth_service.py
- B105: Hardcoded secret password in services/auth_service.py
- B602: Subprocess call with shell=True in services/command_service.py
- B608: SQL Injection in services/data_service.py
- B506: Unsafe YAML loader in services/data_service.py
- B307: Unsafe eval() in services/calc_service.py
